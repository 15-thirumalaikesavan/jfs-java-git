#CREATE DYNAMIC WEB PROJECT
cs90-crud-spring-hibernate-oracle
apache tomcat 9
dynamic web module 3.1
Generate web.xml deployment descriptor.

#SETUP TOMCAT 9
download and extract

switch to web perspective
add server to eclipse
start tomcat and test
port 8080 problem (change to 9090)

#EXPLORE THE WEB PROJECT STRUCTURE
WebContent : (html, css, js, images, pdf (static contnet))
WEB-INF folder contains secure content.

#CREATE A TEST SERVLET
a simple controller with doGet and doPost.